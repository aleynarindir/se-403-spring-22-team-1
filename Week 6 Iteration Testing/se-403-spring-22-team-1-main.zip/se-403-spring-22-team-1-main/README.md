# se-403-spring-22-team-1
SE 403 - Spring '22 - Project Repository for Team 1
---
Team Members
---
1. Canberk Kızılkaya - 190706314
2. Tolga Emre Koraş - 200706042
3. Emin Mert Demirci - 180706023
4. Yunus Emre Tezcan - 170706030
5. Melisa Işıtır - 180706022
6. Aleyna Narin - 190706034
